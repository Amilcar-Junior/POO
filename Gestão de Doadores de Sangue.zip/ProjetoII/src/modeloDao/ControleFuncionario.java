
package modeloDao;

import java.sql.PreparedStatement;
import Objetos.Funcionario;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloConection.ConexaoBD;


public class ControleFuncionario {
    
    ConexaoBD conect = new ConexaoBD();
    
    Funcionario func = new Funcionario();
    
    public void Salvar(Funcionario func){
            conect.conectar();
     
            
            
        try {
          PreparedStatement pst = conect.con.prepareStatement("insert into funcionarios(nome_f,cargo_f,esp_f,email_f,usuario_f,password_f) values(?,?,?,?,?,?);"); 
          pst.setString(1, func.getNome());
          pst.setString(2, func.getCargo());
          pst.setString(3, func.getEspecializacao());
          pst.setString(4, func.getEmail());
          pst.setString(5, func.getUsuario());
          pst.setString(6,func.getPassword());
          pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Inseridos na BD com sucesso");
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao inserir Dados:\n" +ex.getMessage());
        }
        conect.desconectar();
    }
    
    
    
    public Funcionario pesquisarFuncionarios(Funcionario func){
        conect.conectar();
        
        conect.executaSql("select *from funcionarios where nome_f like'%"+func.getPesquisaN()+"%'");
        try {
            conect.rs.first();
            func.setID(conect.rs.getInt("id_f"));
            func.setNome(conect.rs.getString("nome_f"));
            func.setCargo(conect.rs.getString("cargo_f"));
            func.setEspecializacao(conect.rs.getString("esp_f"));
            func.setEmail(conect.rs.getString("email_f"));
            func.setUsuario(conect.rs.getString("usuario_f"));
            func.setPassword(conect.rs.getString("password_f"));
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERRO ao pesquisar Funcionario:\n" +ex.getMessage());       
        }
        
        conect.desconectar();
        return func;
    }
    
    public Funcionario pesquisarFuncionariosID(Funcionario func){
        conect.conectar();
        String sql ="select *from funcionarios where id_f ="+func.getPesquisaID();
        conect.executaSql(sql);
        try {
            conect.rs.first();
            func.setID(conect.rs.getInt("id_f"));
            func.setNome(conect.rs.getString("nome_f"));
            func.setCargo(conect.rs.getString("cargo_f"));
            func.setEspecializacao(conect.rs.getString("esp_f"));
            func.setEmail(conect.rs.getString("email_f"));
            func.setUsuario(conect.rs.getString("usuario_f"));
            func.setPassword(conect.rs.getString("password_f"));
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERRO ao pesquisar Funcionario:\n" +ex.getMessage());       
        }
        
        conect.desconectar();
        return func;
    }
    
    
    public void Alterar(Funcionario func){
        conect.conectar();
        
        try {
            PreparedStatement pst = conect.con.prepareStatement("update funcionarios set nome_f=?,cargo_f=?,esp_f=?,email_f=?,usuario_f=?,password_f=? where id_f=?");
            pst.setString(1, func.getNome());
            pst.setString(2, func.getCargo());
            pst.setString(3, func.getEspecializacao());
            pst.setString(4, func.getEmail());
            pst.setString(5, func.getUsuario());
            pst.setString(6,func.getPassword());
            pst.setInt(7, func.getID());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Alterados com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro na Alteração dos dados!"+ex.getMessage());
            
        }
        
        conect.desconectar();
    }
 
    public void Excluir(Funcionario func){
        conect.conectar();
        
        try {
            PreparedStatement pst = conect.con.prepareStatement("delete from funcionarios where id_f=?");
            pst.setInt(1, func.getID());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Excluido com sucesso!");
           
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Funcionario!"+ex.getMessage());

        }
        
        conect.desconectar();
    }
   
}
