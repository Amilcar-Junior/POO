
package Objetos;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

public class Tabela extends AbstractTableModel{
    
    private ArrayList linhas = null;
    private String[] colunas = null;
    
public Tabela(ArrayList l, String[] c){
    setLinhas(l);
    setColunas(c);   
}

    public ArrayList getLinhas() {
        return linhas;
    }

    public void setLinhas(ArrayList linhas) {
        this.linhas = linhas;
    }

    public String[] getColunas() {
        return colunas;
    }

    public void setColunas(String[] colunas) {
        this.colunas = colunas;
    }

    public int getColumnCount(){
        return colunas.length;//conta a quantidade de colunas
    }
    
    public int getRowCount(){
        return linhas.size();//conta linhas do array
    }
    
    public String getColumnName(int numCol){
        return colunas[numCol];       
    }
    
    public Object getValueAt(int numLin, int numCol){
        Object[] linha = (Object[])getLinhas().get(numLin);
        return linha[numCol];
        
    }
    
    
}


