/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Telas;


import Objetos.Receptor;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import modeloConection.ConexaoBD;
import modeloDao.ControleReceptor;
import util.ManipularImagem;


/**
 *
 * @author Amilc
 */
public class TelaR_GerirReceptor extends javax.swing.JFrame {
    
    BufferedImage imagen;
   
    Date data = new Date();
    SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy");
    
    
    Receptor r = new Receptor();
    ConexaoBD conex = new ConexaoBD();
    ControleReceptor control = new ControleReceptor();
    ManipularImagem manipular = new ManipularImagem();
    
    
    /**
     * Creates new form Login
     */
    public TelaR_GerirReceptor() {
        initComponents();
        this.setLocationRelativeTo(null);
        String dataFormatada = formatar.format(data);
        //jlData.setText(dataFormatada);
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jProgressBar1 = new javax.swing.JProgressBar();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jsIdade = new javax.swing.JSpinner();
        jcbSexo = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jtfNomeR = new javax.swing.JTextField();
        jlFoto = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jtfEmail = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jtfEndereco = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jffTelefone = new javax.swing.JFormattedTextField();
        jffNascimento = new javax.swing.JFormattedTextField();
        jffIdentidade = new javax.swing.JFormattedTextField();
        jLabel19 = new javax.swing.JLabel();
        jlData = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jtfPesquisar = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jlSalvar = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jlAlterar = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jlExcluir = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jlPesquisar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jlID = new javax.swing.JLabel();

        jFormattedTextField1.setText("jFormattedTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/Hospital.png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(175, 28, 76));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Recepcionista");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 280, 500));

        jPanel2.setBackground(new java.awt.Color(175, 28, 76));
        jPanel2.setForeground(new java.awt.Color(175, 28, 76));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe UI", 2, 10)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Sua saúde com certeza.");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(481, 475, 121, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Data Nascimento:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 150, 98, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Idade:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 250, 34, -1));

        jsIdade.setModel(new javax.swing.SpinnerNumberModel(16, 16, null, 1));
        jsIdade.setEnabled(false);
        jPanel2.add(jsIdade, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 250, -1, -1));

        jcbSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sexo", "Masculino", "Feminino" }));
        jcbSexo.setEnabled(false);
        jPanel2.add(jcbSexo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 200, -1));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nome do receptor");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 200, -1));

        jtfNomeR.setEnabled(false);
        jtfNomeR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfNomeRActionPerformed(evt);
            }
        });
        jPanel2.add(jtfNomeR, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 200, -1));

        jlFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_user_100px.png"))); // NOI18N
        jlFoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jlFoto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlFoto.setEnabled(false);
        jlFoto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlFotoMouseClicked(evt);
            }
        });
        jPanel2.add(jlFoto, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 290, -1, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Identidade");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 200, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Email");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, 200, -1));

        jtfEmail.setEnabled(false);
        jPanel2.add(jtfEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 340, 200, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Endereço");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 200, -1));

        jtfEndereco.setEnabled(false);
        jPanel2.add(jtfEndereco, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 200, 200, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 0, 11)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Telefone");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 200, -1));

        try {
            jffTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jffTelefone.setEnabled(false);
        jPanel2.add(jffTelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 250, 116, -1));

        try {
            jffNascimento.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jffNascimento.setEnabled(false);
        jPanel2.add(jffNascimento, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 150, 99, -1));

        try {
            jffIdentidade.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jffIdentidade.setEnabled(false);
        jPanel2.add(jffIdentidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, 200, -1));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_back_to_20px_1.png"))); // NOI18N
        jLabel19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, -1, -1));

        jlData.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jlData.setForeground(new java.awt.Color(255, 255, 255));
        jlData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel2.add(jlData, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 80, 26));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Registro:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 26));

        jtfPesquisar.setForeground(new java.awt.Color(175, 28, 76));
        jtfPesquisar.setText("Pesquisar");
        jtfPesquisar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jtfPesquisarFocusGained(evt);
            }
        });
        jPanel2.add(jtfPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 54, 142, 35));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_save_20px.png"))); // NOI18N
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(236, 54, -1, 35));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jlSalvar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlSalvar.setForeground(new java.awt.Color(175, 28, 76));
        jlSalvar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlSalvar.setText("Salvar");
        jlSalvar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jlSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlSalvar.setEnabled(false);
        jlSalvar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlSalvarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlSalvar, javax.swing.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlSalvar, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(266, 54, -1, -1));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jlAlterar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlAlterar.setForeground(new java.awt.Color(175, 28, 76));
        jlAlterar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlAlterar.setText("Alterar");
        jlAlterar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jlAlterar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlAlterar.setEnabled(false);
        jlAlterar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlAlterarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlAlterar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 54, -1, 35));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_edit_20px.png"))); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(371, 54, -1, 35));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_delete_20px.png"))); // NOI18N
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 54, -1, 35));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jlExcluir.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlExcluir.setForeground(new java.awt.Color(175, 28, 76));
        jlExcluir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlExcluir.setText("Excluir");
        jlExcluir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jlExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jlExcluir.setEnabled(false);
        jlExcluir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlExcluirMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlExcluir, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(517, 56, -1, -1));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jlPesquisar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8_search_20px_1.png"))); // NOI18N
        jlPesquisar.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jlPesquisar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jlPesquisarMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlPesquisar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlPesquisar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 54, -1, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ID:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, -1, 26));

        jlID.setForeground(new java.awt.Color(255, 255, 255));
        jlID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        jPanel2.add(jlID, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 150, 31, 26));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 0, 620, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jtfNomeRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfNomeRActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfNomeRActionPerformed

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
        // TODO add your handling code here:
        TelaR_Recepcionista telaRecep = new TelaR_Recepcionista();
        telaRecep.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jlFotoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlFotoMouseClicked
        // TODO add your handling code here:
        JFileChooser fc = new JFileChooser();
        int res = fc.showOpenDialog(null);

        if (res == JFileChooser.APPROVE_OPTION) {
            File arquivo = fc.getSelectedFile();

            try {
                imagen = ManipularImagem.setImagemDimensao(arquivo.getAbsolutePath(), 120, 120);

                jlFoto.setIcon(new ImageIcon(imagen));

            } catch (Exception ex) {
               // System.out.println(ex.printStackTrace().toString());
            }

        } else {
            JOptionPane.showMessageDialog(null, "Voce não selecionou nenhum arquivo.");
        }
            //gerenteDeImagens.escolherImagem(jlFoto);

    }//GEN-LAST:event_jlFotoMouseClicked

    private void jlPesquisarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlPesquisarMouseClicked
        // TODO add your handling code here:
        r.setPesquisarID(Integer.parseInt(jtfPesquisar.getText()));
        Receptor r1 = control.pesquisarReceptores(r);
        
        jlID.setText(String.valueOf(r1.getCodigoReceptor()));
        jffNascimento.setText(r1.getNascimento());
        jcbSexo.setSelectedItem(r1.getSexo());
        jtfNomeR.setText(r1.getNomeDoador());
        jtfEmail.setText(r1.getEmail());
        jffIdentidade.setText(r1.getIdentidade());
        jtfEndereco.setText(r1.getEndereco());
        jsIdade.setValue(r1.getIdade());
        jffTelefone.setText(String.valueOf(r1.getTelefone()));
        jlData.setText(r1.getDataRegistro());
        ManipularImagem.exibiImagemLabel(r1.getImagen(), jlFoto);
        jlAlterar.setEnabled(true);
        jlExcluir.setEnabled(true);
    }//GEN-LAST:event_jlPesquisarMouseClicked

    private void jtfPesquisarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtfPesquisarFocusGained
        // TODO add your handling code here:
        jtfPesquisar.setText("");
    }//GEN-LAST:event_jtfPesquisarFocusGained

    private void jlAlterarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlAlterarMouseClicked
        // TODO add your handling code here:
        jlExcluir.setEnabled(false);
        jlAlterar.setEnabled(false);
        jlSalvar.setEnabled(true);
        jtfEmail.setEnabled(true);
        jtfEndereco.setEnabled(true);
        jtfNomeR.setEnabled(true);
        jffIdentidade.setEnabled(true);
        jffNascimento.setEnabled(true);
        jffTelefone.setEnabled(true);
        jlFoto.setEnabled(true);
        jsIdade.setEnabled(true);
        jcbSexo.setEnabled(true);
        
    }//GEN-LAST:event_jlAlterarMouseClicked

    private void jlSalvarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlSalvarMouseClicked
        // TODO add your handling code here:
        
        int num=Integer.parseInt(jffTelefone.getText().replace("-", ""));
        r.setCodigoReceptor(Integer.parseInt(jlID.getText()));
        r.setDataRegistro(jlData.getText());
        r.setIdade(Integer.parseInt(jsIdade.getValue().toString()));
        r.setEmail(jtfEmail.getText());
        r.setNomeReceptor(jtfNomeR.getText());
        r.setIdentidade(jffIdentidade.getText());
        r.setTelefone(num);
        r.setSexo((String)jcbSexo.getSelectedItem()); 
        
        //d.setImagen(ManipularImagem.getImgBytes(imagen));        
        control.Alterar(r);
        
        jlSalvar.setEnabled(false);
        jtfEmail.setEnabled(false);
        jtfEndereco.setEnabled(false);
        jtfNomeR.setEnabled(!true);
        jffIdentidade.setEnabled(!true);
        jffNascimento.setEnabled(!true);
        jffTelefone.setEnabled(!true);
        jlFoto.setEnabled(!true);
        jsIdade.setEnabled(!true);
        jcbSexo.setEnabled(!true);
        jlExcluir.setEnabled(!true);
        jlAlterar.setEnabled(false);
            jlID.setText("");
             jffNascimento.setText("");
            jcbSexo.setSelectedItem("Sexo");
            jtfNomeR.setText("");
            jtfEmail.setText("");
            jffIdentidade.setText("");
            jtfEndereco.setText("");
            jsIdade.setValue(16);
            jffTelefone.setText("");
            jlData.setText("");
            jlFoto.setIcon(null);
    }//GEN-LAST:event_jlSalvarMouseClicked

    private void jlExcluirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jlExcluirMouseClicked
        // TODO add your handling code here:
        int resposta = JOptionPane.showConfirmDialog(null, "Deseja Excluir o Receptor do Sistema?");
        if(resposta == JOptionPane.YES_OPTION){
            r.setCodigoReceptor(Integer.parseInt(jlID.getText()));
            control.Eliminar(r);
            jlAlterar.setEnabled(false);
            jlExcluir.setEnabled(false);
            jlID.setText("");
             jffNascimento.setText("");
            jcbSexo.setSelectedItem("Sexo");
            jtfNomeR.setText("");
            jtfEmail.setText("");
            jffIdentidade.setText("");
            jtfEndereco.setText("");
            jsIdade.setValue(16);
            jffTelefone.setText("");
            jlData.setText("");
            jlFoto.setIcon(null);
            
        }else{
            JOptionPane.showMessageDialog(null, "Receptor não foi Excluido!");
        }
        
    }//GEN-LAST:event_jlExcluirMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaR_GerirReceptor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaR_GerirReceptor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaR_GerirReceptor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaR_GerirReceptor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                    new TelaR_GerirReceptor().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JComboBox<String> jcbSexo;
    private javax.swing.JFormattedTextField jffIdentidade;
    private javax.swing.JFormattedTextField jffNascimento;
    private javax.swing.JFormattedTextField jffTelefone;
    private javax.swing.JLabel jlAlterar;
    private javax.swing.JLabel jlData;
    private javax.swing.JLabel jlExcluir;
    private javax.swing.JLabel jlFoto;
    private javax.swing.JLabel jlID;
    private javax.swing.JLabel jlPesquisar;
    private javax.swing.JLabel jlSalvar;
    private javax.swing.JSpinner jsIdade;
    private javax.swing.JTextField jtfEmail;
    private javax.swing.JTextField jtfEndereco;
    private javax.swing.JTextField jtfNomeR;
    private javax.swing.JTextField jtfPesquisar;
    // End of variables declaration//GEN-END:variables
}
