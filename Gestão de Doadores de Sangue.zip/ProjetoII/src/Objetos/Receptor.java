/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objetos;

/**
 *
 * @author Amilc
 */
public class Receptor {
    
    private int codigoReceptor;
    private String nascimento;
    private int idade;
    private String sexo;
    private String nomeReceptor;
    private String identidade;
    private String email;
    private String endereco;
    private int telefone;
    private int sangueRecebido;
    private int sangueNecessario;    
    private String tipoSanguinio;
    private String compativel;
    private String dataRegistro;
    private String NomeDoador;
    private boolean atendido;
    private byte[] imagen;
    private int pesquisarID;

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public int getPesquisarID() {
        return pesquisarID;
    }

    public void setPesquisarID(int pesquisarID) {
        this.pesquisarID = pesquisarID;
    }
    
    

    public int getCodigoReceptor() {
        return codigoReceptor;
    }

    public void setCodigoReceptor(int codigoReceptor) {
        this.codigoReceptor = codigoReceptor;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNomeReceptor() {
        return nomeReceptor;
    }

    public void setNomeReceptor(String nomeReceptor) {
        this.nomeReceptor = nomeReceptor;
    }


    public String getIdentidade() {
        return identidade;
    }

    public void setIdentidade(String identidade) {
        this.identidade = identidade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    
    public int getSangueNecessario() {
        return sangueNecessario;
    }

    public void setSangueNecessario(int sangueNecessario) {
        this.sangueNecessario = sangueNecessario;
    }

    public boolean isAtendido() {
        return atendido;
    }

    public void setAtendido(boolean atendido) {
        this.atendido = atendido;
    }

    public String getTipoSanguinio() {
        return tipoSanguinio;
    }

    public void setTipoSanguinio(String tipoSanguinio) {
        this.tipoSanguinio = tipoSanguinio;
    }

    public String getCompativel() {
        return compativel;
    }

    public void setCompativel(String compativel) {
        this.compativel = compativel;
    }

    public int getSangueRecebido() {
        return sangueRecebido;
    }

    public void setSangueRecebido(int sangueRecebido) {
        this.sangueRecebido = sangueRecebido;
    }

    public String getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(String dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public String getNomeDoador() {
        return NomeDoador;
    }

    public void setNomeDoador(String NomeDoador) {
        this.NomeDoador = NomeDoador;
    }
    
    
    
}
