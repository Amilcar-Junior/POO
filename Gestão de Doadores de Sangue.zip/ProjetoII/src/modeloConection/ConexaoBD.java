
package modeloConection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexaoBD {
    
    public Statement stm; //responsavel para pesquisar a BD
    public ResultSet rs; //armazena a pesquisa
    public Connection con; // conecta com a BD    
    
    public void conectar(){
    
        try {
            System.setProperty("jdbc.driver", "org.postgresql.Driver");
            con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/BDHosp", "postgres", "Deusejesus");
           // JOptionPane.showMessageDialog(null, "Conectado!");
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro de Conexã:\n"+ex.getMessage());
        }
    }
       
    public void desconectar(){
        try {
            con.close();
           // JOptionPane.showMessageDialog(null, "Desconectado!");
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao Descnoectar da BD:\n"+ex.getMessage());
        }
    }
    
    
    
    public void executaSql(String sql){
        try {
            stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY); // type_scroll... defere maiusculo de minusculo //concur percore toda a tabela
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoBD.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL:\n"+ex.getMessage());
        }       
    }
}
