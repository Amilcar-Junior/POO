
package Objetos;

public class Funcionario {

    
    private int ID;
    private String nome;
    private String cargo;
    private String especializacao;
    private String email;
    private String usuario;
    private String password;
    private String pesquisaN;
    private int PesquisaID;

    public int getPesquisaID() {
        return PesquisaID;
    }

    public void setPesquisaID(int PesquisaID) {
        this.PesquisaID = PesquisaID;
    }

    
    public String getPesquisaN() {
        return pesquisaN;
    }

    public void setPesquisaN(String pesquisaN) {
        this.pesquisaN = pesquisaN;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    
    
}