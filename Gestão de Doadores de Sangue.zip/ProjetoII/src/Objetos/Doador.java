
package Objetos;

public class Doador {
    
    private int codigoDoador;
    private String nascimento;
    private int idade;
    private String sexo;
    private String nomeDoador;
    private String nomePai;
    private String nomeMae;
    private String nacionalidade;
    private String naturalidade;
    private String identidade;
    private String email;
    private String endereco;
    private int telefone;
    private byte[] imagen;
    private boolean apto;
    private boolean hematológicaApto;
    private boolean massaCApto;
    private boolean temperaturaApto;
    private boolean pressaoApto;
    private boolean frequenciaCApto;
    private String tipoSanguinio = "";
    private int qntSangueDoados = 0; 
    private String doencas = "";
    private String compativel = "";
    private String dataRegistro;
    private int pesquisarID;

    public int getPesquisarID() {
        return pesquisarID;
    }

    public void setPesquisarID(int pesquisarID) {
        this.pesquisarID = pesquisarID;
    }
    
    
    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    
    
    
    public int getCodigoDoador() {
        return codigoDoador;
    }

    public void setCodigoDoador(int codigoDoador) {
        this.codigoDoador = codigoDoador;
    }

    public String getNascimento() {
        return nascimento;
    }

    public void setNascimento(String nascimento) {
        this.nascimento = nascimento;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getNomeDoador() {
        return nomeDoador;
    }

    public void setNomeDoador(String nomeDoador) {
        this.nomeDoador = nomeDoador;
    }

    public String getNomePai() {
        return nomePai;
    }

    public void setNomePai(String nomePai) {
        this.nomePai = nomePai;
    }

    public String getNomeMae() {
        return nomeMae;
    }

    public void setNomeMae(String nomeMae) {
        this.nomeMae = nomeMae;
    }

    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

    public String getNaturalidade() {
        return naturalidade;
    }

    public void setNaturalidade(String naturalidade) {
        this.naturalidade = naturalidade;
    }

    public String getIdentidade() {
        return identidade;
    }

    public void setIdentidade(String identidade) {
        this.identidade = identidade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public boolean isApto() {
        return apto;
    }

    public void setApto(boolean apto) {
        this.apto = apto;
    }

    public boolean isHematológicaApto() {
        return hematológicaApto;
    }

    public void setHematológicaApto(boolean hematológicaApto) {
        this.hematológicaApto = hematológicaApto;
    }

    public boolean isMassaCApto() {
        return massaCApto;
    }

    public void setMassaCApto(boolean massaCApto) {
        this.massaCApto = massaCApto;
    }

    public boolean isTemperaturaApto() {
        return temperaturaApto;
    }

    public void setTemperaturaApto(boolean temperaturaApto) {
        this.temperaturaApto = temperaturaApto;
    }

    public boolean isPressaoApto() {
        return pressaoApto;
    }

    public void setPressaoApto(boolean pressaoApto) {
        this.pressaoApto = pressaoApto;
    }

    public boolean isFrequenciaCApto() {
        return frequenciaCApto;
    }

    public void setFrequenciaCApto(boolean frequenciaCApto) {
        this.frequenciaCApto = frequenciaCApto;
    }

    public String getTipoSanguinio() {
        return tipoSanguinio;
    }

    public void setTipoSanguinio(String tipoSanguinio) {
        this.tipoSanguinio = tipoSanguinio;
    }

    public int getQntSangueDoados() {
        return qntSangueDoados;
    }

    public void setQntSangueDoados(int qntSangueDoados) {
        this.qntSangueDoados = qntSangueDoados;
    }


    public String getDoencas() {
        return doencas;
    }

    public void setDoencas(String doencas) {
        this.doencas = doencas;
    }

    public String getCompativel() {
        return compativel;
    }

    public void setCompativel(String compativel) {
        this.compativel = compativel;
    }

    public String getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(String dataRegistro) {
        this.dataRegistro = dataRegistro;
    }
    
    
    
    
}
