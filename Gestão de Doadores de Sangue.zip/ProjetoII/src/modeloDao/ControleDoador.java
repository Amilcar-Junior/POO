
package modeloDao;


import Objetos.Doador;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloConection.ConexaoBD;

public class ControleDoador {
    
    ConexaoBD conect = new ConexaoBD();
    
    Doador d = new Doador();
    
    public void Salvar(Doador d){
        conect.conectar();
        
        try { 
            PreparedStatement pst = conect.con.prepareStatement("insert into doadores(data_n_d,idade_d,sexo_d,nomed_d,nomem_d,nomep_d,nacionalidade_d,naturalidade_d,identidade_d,email_d,endereco_d,telefone_d,hematologica_d,massa_d,temperatura_d,pressao_d,frequencia_d,compativel_d,sanguedoado_d,doenca_d,dataregistro_d,tsanguinio_d,apto_d,imagen_d) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
            pst.setString(1, d.getNascimento());
            pst.setInt(2, d.getIdade());
            pst.setString(3, d.getSexo());
            pst.setString(4, d.getNomeDoador());
            pst.setString(5, d.getNomeMae());
            pst.setString(6, d.getNomePai());
            pst.setString(7, d.getNacionalidade());
            pst.setString(8, d.getNaturalidade());
            pst.setInt(9, Integer.parseInt(d.getIdentidade()));
            pst.setString(10, d.getEmail());
            pst.setString(11, d.getEndereco());
            pst.setInt(12, d.getTelefone());
            pst.setBoolean(13, d.isHematológicaApto());
            pst.setBoolean(14, d.isMassaCApto());
            pst.setBoolean(15, d.isTemperaturaApto());
            pst.setBoolean(16, d.isPressaoApto());
            pst.setBoolean(17, d.isFrequenciaCApto());
            pst.setString(18, d.getCompativel());
            pst.setInt(19, d.getQntSangueDoados());
            pst.setString(20, d.getDoencas());
            pst.setString(21, d.getDataRegistro());
            pst.setString(22, d.getTipoSanguinio());
            pst.setBoolean(23, d.isApto());
            pst.setBytes(24, d.getImagen());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados Inseridos na BD com sucesso");
            
        
        } catch (SQLException ex) {
            Logger.getLogger(ControleDoador.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao inserir Dados:\n" +ex.getMessage());
        }
        
        
        conect.desconectar();
    }
    
    public Doador pesquisarDoadores(Doador d){
        conect.conectar();
        String sql = "select *from doadores where id_d =" +d.getPesquisarID();
        conect.executaSql(sql);
        try {
            conect.rs.first();
            d.setCodigoDoador(conect.rs.getInt("id_d"));
            d.setNascimento(conect.rs.getString("data_n_d"));
            d.setIdade(conect.rs.getInt("idade_d"));
            d.setSexo(conect.rs.getString("sexo_d"));
            d.setNomeDoador(conect.rs.getString("nomed_d"));
            d.setNomeMae(conect.rs.getString("nomem_d"));
            d.setNomePai(conect.rs.getString("nomep_d"));
            d.setNacionalidade(conect.rs.getString("nacionalidade_d"));
            d.setNaturalidade(conect.rs.getString("naturalidade_d"));
            d.setIdentidade(String.valueOf(conect.rs.getInt("identidade_d")));
            d.setEmail(conect.rs.getString("email_d"));
            d.setEndereco(conect.rs.getString("endereco_d"));
            d.setTelefone(Integer.parseInt(conect.rs.getString("telefone_d")));
            d.setHematológicaApto(conect.rs.getBoolean("hematologica_d"));
            d.setMassaCApto(conect.rs.getBoolean("massa_d"));
            d.setTemperaturaApto(conect.rs.getBoolean("temperatura_d"));
            d.setPressaoApto(conect.rs.getBoolean("pressao_d"));
            d.setFrequenciaCApto(conect.rs.getBoolean("frequencia_d"));
            d.setCompativel(conect.rs.getString("compativel_d"));
            d.setQntSangueDoados(Integer.parseInt(conect.rs.getString("sanguedoado_d")));
            d.setDoencas(conect.rs.getString("doenca_d"));
            d.setDataRegistro(conect.rs.getString("dataregistro_d"));
            d.setTipoSanguinio(conect.rs.getString("tsanguinio_d"));
            d.setApto(conect.rs.getBoolean("apto_d"));
            d.setImagen(conect.rs.getBytes("imagen_d"));
            
        } catch (SQLException ex) {
            Logger.getLogger(ControleDoador.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERRO ao pesquisar Doador:\n" +ex.getMessage());       

        }
        conect.desconectar();
        return d;
    }
    
    public void Alterar(Doador d){
        conect.conectar();
        try {
            PreparedStatement pst = conect.con.prepareStatement("update doadores set data_n_d=?,idade_d=?,sexo_d=?,nomed_d=?,nomem_d=?,nomep_d=?,nacionalidade_d=?,naturalidade_d=?,identidade_d=?,email_d=?,endereco_d=?,telefone_d=?,hematologica_d=?,massa_d=?,temperatura_d=?,pressao_d=?,frequencia_d=?,compativel_d=?,sanguedoado_d=?,doenca_d=?,dataregistro_d=?,tsanguinio_d=?,apto_d=?,imagen_d=? where id_d=?");
            pst.setString(1, d.getNascimento());
            pst.setInt(2, d.getIdade());
            pst.setString(3, d.getSexo());
            pst.setString(4, d.getNomeDoador());
            pst.setString(5, d.getNomeMae());
            pst.setString(6, d.getNomePai());
            pst.setString(7, d.getNacionalidade());
            pst.setString(8, d.getNaturalidade());
            pst.setInt(9, Integer.parseInt(d.getIdentidade()));
            pst.setString(10, d.getEmail());
            pst.setString(11, d.getEndereco());
            pst.setInt(12, d.getTelefone());
            pst.setBoolean(13, d.isHematológicaApto());
            pst.setBoolean(14, d.isMassaCApto());
            pst.setBoolean(15, d.isTemperaturaApto());
            pst.setBoolean(16, d.isPressaoApto());
            pst.setBoolean(17, d.isFrequenciaCApto());
            pst.setString(18, d.getCompativel());
            pst.setInt(19, d.getQntSangueDoados());
            pst.setString(20, d.getDoencas());
            pst.setString(21, d.getDataRegistro());
            pst.setString(22, d.getTipoSanguinio());
            pst.setBoolean(23, d.isApto());
            pst.setBytes(24, d.getImagen());
            pst.setInt(25, d.getCodigoDoador());
            
            pst.execute();
            
            
            
            JOptionPane.showMessageDialog(null, "Dados Alterados com sucesso!");
        
        } catch (SQLException ex) {
            Logger.getLogger(ControleDoador.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro na Alteração dos dados!"+ex.getMessage());        
        }

        
        conect.conectar();
    }
    
    public void Eliminar(Doador d){
        conect.conectar();
        
        try {
            PreparedStatement pst = conect.con.prepareStatement("delete from doadores where id_d=?");
            pst.setInt(1, d.getCodigoDoador());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Excluido com sucesso!");
           
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Doador!"+ex.getMessage());

        }
        
        conect.desconectar();
        
    }
    
}
