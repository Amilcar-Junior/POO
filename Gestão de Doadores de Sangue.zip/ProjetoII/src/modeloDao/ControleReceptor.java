
package modeloDao;



import Objetos.Receptor;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloConection.ConexaoBD;

public class ControleReceptor {
    
    ConexaoBD conect = new ConexaoBD();
    
    Receptor r = new Receptor();
    
    public void Salvar(Receptor r){
        conect.conectar();
        
        try { 
            PreparedStatement pst = conect.con.prepareStatement("insert into receptores(data_n_r,idade_r,sexo_r,nomer_r,identidade_r,email_r,endereco_r,telefone_r,sangue_recebido_r,sangue_necessario_r,tsanguinio_r,compativel_r,data_r_r,nomed_r,atendido_r,imagen_r) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
            pst.setString(1, r.getNascimento());
            pst.setInt(2, r.getIdade());
            pst.setString(3, r.getSexo());
            pst.setString(4, r.getNomeReceptor());
            pst.setInt(5, Integer.parseInt(r.getIdentidade()));
            pst.setString(6, r.getEmail());
            pst.setString(7, r.getEndereco());
            pst.setInt(8, r.getTelefone());
            pst.setInt(9, r.getSangueRecebido());
            pst.setInt(10, r.getSangueNecessario());
            pst.setString(11, r.getTipoSanguinio());
            pst.setString(12, r.getCompativel());
            pst.setString(13, r.getDataRegistro());
            pst.setString(14, r.getNomeDoador());
            pst.setBoolean(15, r.isAtendido());
            pst.setBytes(16, r.getImagen());

            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Dados Inseridos na BD com sucesso");
            
        
        } catch (SQLException ex) {
            Logger.getLogger(ControleReceptor.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao inserir Dados:\n" +ex.getMessage());
        }
        
        
        conect.desconectar();
    }
    
    public Receptor pesquisarReceptores(Receptor r){
        conect.conectar();
        String sql = "select *from receptores where id_r =" +r.getPesquisarID();
        conect.executaSql(sql);
        try {
            conect.rs.first();
            r.setCodigoReceptor(conect.rs.getInt("id_r"));
            r.setNascimento(conect.rs.getString("data_n_r"));
            r.setIdade(conect.rs.getInt("idade_r"));
            r.setSexo(conect.rs.getString("sexo_r"));
            r.setNomeReceptor(conect.rs.getString("nomer_r"));
            r.setIdentidade(String.valueOf(conect.rs.getInt("identidade_r")));
            r.setEmail(conect.rs.getString("email_r"));
            r.setEndereco(conect.rs.getString("endereco_r"));
            r.setTelefone(Integer.parseInt(conect.rs.getString("telefone_r")));
            r.setSangueRecebido(conect.rs.getInt("sangue_recebido_r"));
            r.setSangueNecessario(conect.rs.getInt("sangue_necessario_r"));
            r.setTipoSanguinio(conect.rs.getString("tsanguinio_r"));
            r.setCompativel(conect.rs.getString("compativel_r"));
            r.setDataRegistro(conect.rs.getString("data_r_r"));
            r.setNomeDoador(conect.rs.getString("nomed_r"));
            r.setAtendido(conect.rs.getBoolean("atendido_r"));
            r.setImagen(conect.rs.getBytes("imagen_r"));
            
        } catch (SQLException ex) {
            Logger.getLogger(ControleReceptor.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "ERRO ao pesquisar Receptor:\n" +ex.getMessage());       

        }
        conect.desconectar();
        return r;
    }
    
    public void Alterar(Receptor r){
        conect.conectar();
        try {
            PreparedStatement pst = conect.con.prepareStatement("update receptores set data_n_r=?,idade_r=?,sexo_r=?,nomer_r=?,identidade_r=?,email_r=?,endereco_r=?,telefone_r=?,sangue_recebido_r=?,sangue_necessario_r=?,tsanguinio_r=?,compativel_r=?,data_r_r=?,nomed_r=?,atendido_r=?,imagen_r=? where id_r=?");
            pst.setString(1, r.getNascimento());
            pst.setInt(2, r.getIdade());
            pst.setString(3, r.getSexo());
            pst.setString(4, r.getNomeReceptor());
            pst.setInt(5, Integer.parseInt(r.getIdentidade()));
            pst.setString(6, r.getEmail());
            pst.setString(7, r.getEndereco());
            pst.setInt(8, r.getTelefone());
            pst.setInt(9, r.getSangueRecebido());
            pst.setInt(10, r.getSangueNecessario());
            pst.setString(11, r.getTipoSanguinio());
            pst.setString(12, r.getCompativel());
            pst.setString(13, r.getDataRegistro());
            pst.setString(14, r.getNomeDoador());
            pst.setBoolean(15, r.isAtendido());
            pst.setBytes(16, r.getImagen());
            pst.setInt(17, r.getCodigoReceptor());
            
            pst.execute();
            
            
            
            JOptionPane.showMessageDialog(null, "Dados Alterados com sucesso!");
        
        } catch (SQLException ex) {
            Logger.getLogger(ControleReceptor.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro na Alteração dos dados!"+ex.getMessage());        
        }

        
        conect.conectar();
    }
    
    public void Eliminar(Receptor r){
        conect.conectar();
        
        try {
            PreparedStatement pst = conect.con.prepareStatement("delete from receptores where id_r=?");
            pst.setInt(1, r.getCodigoReceptor());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados Excluido com sucesso!");
           
        } catch (SQLException ex) {
            Logger.getLogger(ControleFuncionario.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Receptor!"+ex.getMessage());

        }
        
        conect.desconectar();
        
    }
    
}
